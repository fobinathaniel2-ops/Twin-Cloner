package top.niunaijun.blackboxa.view.twin

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackbox.utils.AbiUtils

class AppRow(
    val pkg: String,
    val label: String,
    val icon: Drawable?,
    val source: String,
    val cloned: Boolean
)

/** Full-screen app chooser. Returns source/pkg/name to TwinHomeActivity. */
class PickerActivity : Activity() {
    private var userId = 0
    private var all: List<AppRow> = emptyList()
    private lateinit var list: RecyclerView
    private lateinit var status: TextView

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupTwinWindow()
        userId = intent.getIntExtra("userID", 0)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(T.bg)
        root.setPadding(dp(20), dp(12), dp(20), 0)
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(dp(20), ins.systemWindowInsetTop + dp(12), dp(20), ins.systemWindowInsetBottom)
            ins
        }

        val back = tv("\u2190  Back", 15f, T.accent, true)
        back.setPadding(0, dp(8), dp(16), dp(8))
        back.setOnClickListener { Haptic.tap(it); finish() }
        root.addView(back)
        root.addView(tv("Choose an app", 30f, T.text, true))
        val sub = tv("It will be cloned into ${Store.spaceName(userId)}.", 14f, T.muted)
        sub.setPadding(0, dp(2), 0, dp(12))
        root.addView(sub)

        val search = EditText(this)
        search.hint = "Search apps"
        search.setSingleLine(true)
        search.setTextColor(T.text)
        search.setHintTextColor(T.muted)
        search.textSize = 16f
        search.background = rr(T.card, 24)
        search.setPadding(dp(18), dp(12), dp(18), dp(12))
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(search, LinearLayout.LayoutParams(-1, -2))

        status = tv("Loading your apps\u2026", 14f, T.muted)
        status.gravity = Gravity.CENTER
        status.setPadding(0, dp(24), 0, 0)
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this)
        list.layoutManager = LinearLayoutManager(this)
        list.clipToPadding = false
        list.setPadding(0, dp(8), 0, dp(16))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        load()
    }

    private fun load() {
        Thread {
            val rows = ArrayList<AppRow>()
            try {
                val core = BlackBoxCore.get()
                val pm = BlackBoxCore.getPackageManager()
                val apps: List<ApplicationInfo> = pm.getInstalledApplications(0)
                for (ai in apps) {
                    try {
                        if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
                        if (!AbiUtils.isSupport(File(ai.sourceDir))) continue
                        if (core.isBlackBoxApp(ai.packageName)) continue
                        val icon: Drawable? = try { pm.getApplicationIcon(ai) } catch (e: Exception) { null }
                        rows.add(
                            AppRow(
                                ai.packageName,
                                pm.getApplicationLabel(ai).toString(),
                                icon,
                                ai.sourceDir,
                                core.isInstalled(ai.packageName, userId)
                            )
                        )
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Throwable) {
            }
            rows.sortBy { it.label.lowercase() }
            runOnUiThread {
                all = rows
                render("")
            }
        }.start()
    }

    private fun render(q: String) {
        val shown = all.filter { it.label.contains(q, ignoreCase = true) }
        status.visibility = if (shown.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        status.text = if (all.isEmpty()) "Loading your apps\u2026" else "No apps match \u201C$q\u201D"
        list.adapter = PickerAdapter(shown) { row, v ->
            if (row.cloned) {
                Haptic.tap(v)
                Toast.makeText(this, "${row.label} is already in this space", Toast.LENGTH_SHORT).show()
            } else {
                Haptic.tap(v, true)
                val data = Intent()
                data.putExtra("source", row.source)
                data.putExtra("pkg", row.pkg)
                data.putExtra("name", row.label)
                setResult(RESULT_OK, data)
                finish()
            }
        }
    }

    private inner class PickerAdapter(
        private val items: List<AppRow>,
        private val onTap: (AppRow, android.view.View) -> Unit
    ) : RecyclerView.Adapter<PickerAdapter.VH>() {
        inner class VH(
            val root: LinearLayout,
            val icon: ImageView,
            val name: TextView,
            val pkg: TextView,
            val tag: TextView
        ) : RecyclerView.ViewHolder(root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(this@PickerActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            row.background = rr(T.card, 18)
            val lp = RecyclerView.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8)
            row.layoutParams = lp
            val icon = ImageView(this@PickerActivity)
            row.addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)))
            val texts = LinearLayout(this@PickerActivity)
            texts.orientation = LinearLayout.VERTICAL
            val name = tv("", 16f, T.text, true)
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            val pkg = tv("", 12f, T.muted)
            pkg.maxLines = 1
            pkg.ellipsize = TextUtils.TruncateAt.END
            texts.addView(name)
            texts.addView(pkg)
            val tlp = LinearLayout.LayoutParams(0, -2, 1f)
            tlp.leftMargin = dp(14)
            row.addView(texts, tlp)
            val tag = tv("Cloned", 12f, T.accent, true)
            row.addView(tag)
            return VH(row, icon, name, pkg, tag)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = items[position]
            h.icon.setImageDrawable(item.icon)
            h.name.text = item.label
            h.pkg.text = item.pkg
            h.tag.visibility = if (item.cloned) android.view.View.VISIBLE else android.view.View.GONE
            h.root.alpha = if (item.cloned) 0.55f else 1f
            h.root.setOnClickListener { v -> onTap(item, v) }
        }

        override fun getItemCount(): Int = items.size
    }
}
