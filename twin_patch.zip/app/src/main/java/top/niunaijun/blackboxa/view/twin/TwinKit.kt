package top.niunaijun.blackboxa.view.twin

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.TextView

/** Twin colors. Light = bone paper, dark = night teal. */
object T {
    val teal = Color.parseColor("#0F3D3E")
    val coral = Color.parseColor("#FF6B4A")
    val bone = Color.parseColor("#F3EFE7")
    val night = Color.parseColor("#0E1514")
    var dark = false
    val bg: Int get() = if (dark) night else bone
    val card: Int get() = if (dark) Color.parseColor("#182625") else Color.WHITE
    val text: Int get() = if (dark) Color.parseColor("#EDEBE4") else Color.parseColor("#12201F")
    val muted: Int get() = if (dark) Color.parseColor("#9DB0AE") else Color.parseColor("#5E6F6D")
    val accent: Int get() = if (dark) coral else teal
    val line: Int get() = if (dark) Color.parseColor("#243433") else Color.parseColor("#E4DED2")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rr(color: Int, radiusDp: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(radiusDp).toFloat()
    return g
}

fun Context.tv(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t
    v.textSize = sp
    v.setTextColor(color)
    if (bold) v.typeface = Typeface.DEFAULT_BOLD
    return v
}

@Suppress("DEPRECATION")
fun Activity.setupTwinWindow() {
    Store.init(this)
    val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    T.dark = when (Store.theme) {
        1 -> false
        2 -> true
        else -> night
    }
    window.statusBarColor = T.bg
    window.navigationBarColor = T.card
    var flags = 0
    if (!T.dark) {
        if (Build.VERSION.SDK_INT >= 23) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }
    window.decorView.systemUiVisibility = flags
}

/** Simple on-device storage: profile, settings, device messages. Nothing leaves the phone. */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("twin_store", Context.MODE_PRIVATE)
            if (!sp.contains("since")) sp.edit().putLong("since", System.currentTimeMillis()).apply()
        }
    }

    var name: String
        get() = sp.getString("name", "You") ?: "You"
        set(v) { sp.edit().putString("name", v).apply() }

    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) { sp.edit().putBoolean("haptics", v).apply() }

    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var confirmRemove: Boolean
        get() = sp.getBoolean("confirmRemove", true)
        set(v) { sp.edit().putBoolean("confirmRemove", v).apply() }

    var askedStorage: Boolean
        get() = sp.getBoolean("askedStorage", false)
        set(v) { sp.edit().putBoolean("askedStorage", v).apply() }

    var launches: Int
        get() = sp.getInt("launches", 0)
        set(v) { sp.edit().putInt("launches", v).apply() }

    val since: Long get() = sp.getLong("since", System.currentTimeMillis())

    fun spaceName(id: Int): String = sp.getString("space_$id", null) ?: "Space ${id + 1}"

    fun setSpaceName(id: Int, n: String) { sp.edit().putString("space_$id", n).apply() }

    class Msg(val time: Long, val title: String, val body: String)

    private fun clean(s: String): String = s.replace("\u001E", " ").replace("\u001F", " ")

    fun messages(): List<Msg> {
        val raw = sp.getString("msgs", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        val out = ArrayList<Msg>()
        for (chunk in raw.split("\u001E")) {
            val p = chunk.split("\u001F")
            if (p.size == 3) out.add(Msg(p[0].toLongOrNull() ?: 0L, p[1], p[2]))
        }
        return out
    }

    fun addMessage(title: String, body: String) {
        val list = ArrayList<Msg>()
        list.add(Msg(System.currentTimeMillis(), title, body))
        list.addAll(messages())
        val keep = list.take(60)
        val raw = keep.joinToString("\u001E") { "${it.time}\u001F${clean(it.title)}\u001F${clean(it.body)}" }
        sp.edit().putString("msgs", raw).apply()
    }

    fun clearMessages() { sp.edit().remove("msgs").apply() }

    fun resetProfile() { sp.edit().remove("name").remove("launches").remove("msgs").apply() }
}

object Haptic {
    @Suppress("DEPRECATION")
    fun tap(v: View, strong: Boolean = false) {
        if (!Store.haptics) return
        val vib = v.context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (vib != null && vib.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(VibrationEffect.createOneShot(if (strong) 30L else 12L, if (strong) 200 else 90))
            } else {
                vib.vibrate(if (strong) 30L else 12L)
            }
        } else {
            v.performHapticFeedback(
                if (strong) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.VIRTUAL_KEY
            )
        }
    }
}
