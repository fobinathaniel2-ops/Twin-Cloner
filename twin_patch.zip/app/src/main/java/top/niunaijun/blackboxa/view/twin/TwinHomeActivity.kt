package top.niunaijun.blackboxa.view.twin

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.text.TextUtils
import android.text.format.DateUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackboxa.R

class CloneItem(val pkg: String, val label: String, val icon: Drawable?)

/** Twin home: Clones, Messages, Profile, Settings. Built in code, no XML layouts. */
@Suppress("DEPRECATION")
class TwinHomeActivity : Activity() {
    private lateinit var content: FrameLayout
    private val tabIcons = ArrayList<ImageView>()
    private val tabLabels = ArrayList<TextView>()
    private var tab = 0
    private var space = 0
    private var pendingNew = false
    private var spaceIds: List<Int> = listOf(0)
    private var clones: List<CloneItem> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupTwinWindow()
        core("onBeforeMainActivityOnCreate")
        buildShell()
        show(0)
        core("onAfterMainActivityOnCreate")
        ensureStorage()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (tab == 1 || tab == 3) show(tab)
    }

    override fun onBackPressed() {
        if (tab != 0) show(0) else super.onBackPressed()
    }

    // The engine has start-up hooks; call them without depending on their exact signature.
    private fun core(name: String) {
        try {
            val c = BlackBoxCore.get()
            c.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == 1 }?.invoke(c, this)
        } catch (e: Throwable) {
            Log.w("Twin", "$name: ${e.message}")
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- shell
    private fun buildShell() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(T.bg)

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(T.card)
        bar.setPadding(0, dp(8), 0, dp(8))
        val defs = listOf(
            "Clones" to R.drawable.twin_ic_clones,
            "Messages" to R.drawable.twin_ic_bell,
            "Profile" to R.drawable.twin_ic_person,
            "Settings" to R.drawable.twin_ic_tune
        )
        defs.forEachIndexed { i, d ->
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            val icon = ImageView(this)
            icon.setImageResource(d.second)
            val label = tv(d.first, 11f, T.muted, true)
            item.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            item.addView(label)
            item.setOnClickListener { Haptic.tap(it); show(i) }
            tabIcons.add(icon)
            tabLabels.add(label)
            bar.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(0, ins.systemWindowInsetTop, 0, 0)
            bar.setPadding(0, dp(8), 0, dp(8) + ins.systemWindowInsetBottom)
            ins
        }
        setContentView(root)
    }

    private fun show(i: Int) {
        tab = i
        content.removeAllViews()
        content.addView(
            when (i) {
                0 -> clonesPage()
                1 -> messagesPage()
                2 -> profilePage()
                else -> settingsPage()
            },
            FrameLayout.LayoutParams(-1, -1)
        )
        for (k in tabIcons.indices) {
            val c = if (k == i) T.accent else T.muted
            tabIcons[k].setColorFilter(c)
            tabLabels[k].setTextColor(c)
        }
    }

    // ---------------------------------------------------------------- ui helpers
    private fun page(title: String, sub: String?): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(20), dp(20), dp(24))
        col.addView(tv(title, 30f, T.text, true))
        if (sub != null) {
            val s = tv(sub, 14f, T.muted)
            s.setPadding(0, dp(2), 0, dp(14))
            col.addView(s)
        } else {
            col.addView(View(this), LinearLayout.LayoutParams(1, dp(14)))
        }
        return col
    }

    private fun scroll(col: View): ScrollView {
        val s = ScrollView(this)
        s.isVerticalScrollBarEnabled = false
        s.addView(col)
        return s
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rr(T.card, 20)
        c.setPadding(dp(18), dp(14), dp(18), dp(14))
        return c
    }

    private fun addTo(col: LinearLayout, v: View) {
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(12)
        col.addView(v, lp)
    }

    private fun section(col: LinearLayout, t: String) {
        val s = tv(t.uppercase(), 12f, T.muted, true)
        s.setPadding(dp(4), dp(10), 0, dp(8))
        col.addView(s)
    }

    private fun divider(parent: LinearLayout) {
        val d = View(this)
        d.setBackgroundColor(T.line)
        parent.addView(d, LinearLayout.LayoutParams(-1, 1))
    }

    private fun rowTap(title: String, sub: String, onClick: (View) -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        r.addView(tv(title, 16f, T.text, true))
        r.addView(tv(sub, 13f, T.muted))
        r.setOnClickListener { Haptic.tap(it); onClick(it) }
        return r
    }

    private fun rowSwitch(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(tv(title, 16f, T.text, true))
        texts.addView(tv(sub, 13f, T.muted))
        r.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { b, c -> onChange(c); Haptic.tap(b) }
        r.addView(sw)
        return r
    }

    private fun chip(t: String, selected: Boolean, onClick: (View) -> Unit): TextView {
        val c = tv(t, 14f, if (selected) Color.WHITE else T.text, true)
        c.setPadding(dp(16), dp(9), dp(16), dp(9))
        c.background = rr(if (selected) T.accent else T.card, 20)
        c.setOnClickListener { onClick(it) }
        return c
    }

    // ---------------------------------------------------------------- clones page
    private fun clonesPage(): View {
        val frame = FrameLayout(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(20), dp(20), 0)
        col.addView(tv("Your clones", 30f, T.text, true))
        val sub = tv(
            if (clones.isEmpty()) "Nothing here yet" else "${clones.size} cloned in ${Store.spaceName(space)}",
            14f, T.muted
        )
        sub.setPadding(0, dp(2), 0, dp(12))
        col.addView(sub)

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val ids = if (spaceIds.contains(space)) spaceIds else spaceIds + space
        for (id in ids) {
            val c = chip(Store.spaceName(id), id == space) { v ->
                Haptic.tap(v)
                pendingNew = false
                space = id
                refresh()
            }
            c.setOnLongClickListener { v -> Haptic.tap(v, true); renameSpace(id); true }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.rightMargin = dp(8)
            row.addView(c, lp)
        }
        row.addView(chip("+ New space", false) { v -> Haptic.tap(v); newSpace() })
        hs.addView(row)
        col.addView(hs)

        if (clones.isEmpty()) {
            col.addView(emptyState(), LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            val rv = RecyclerView(this)
            val widthDp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
            rv.layoutManager = GridLayoutManager(this, maxOf(3, (widthDp / 110f).toInt()))
            rv.clipToPadding = false
            rv.setPadding(0, dp(12), 0, dp(110))
            rv.adapter = CloneAdapter(this, clones, { item, v -> launch(item, v) }, { item, v -> holdMenu(item, v) })
            col.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        frame.addView(col, FrameLayout.LayoutParams(-1, -1))

        val fab = tv("+", 34f, Color.WHITE, true)
        fab.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(T.coral)
        fab.background = bg
        fab.elevation = dp(8).toFloat()
        fab.setOnClickListener { Haptic.tap(it, true); openPicker() }
        val flp = FrameLayout.LayoutParams(dp(64), dp(64), Gravity.END or Gravity.BOTTOM)
        flp.setMargins(0, 0, dp(20), dp(20))
        frame.addView(fab, flp)
        return frame
    }

    private fun emptyState(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        val art = FrameLayout(this)
        val left = View(this)
        val lg = GradientDrawable()
        lg.shape = GradientDrawable.OVAL
        lg.setColor(if (T.dark) T.bone else T.teal)
        left.background = lg
        val right = View(this)
        val rg = GradientDrawable()
        rg.shape = GradientDrawable.OVAL
        rg.setColor(T.coral)
        right.background = rg
        art.addView(left, FrameLayout.LayoutParams(dp(84), dp(84)))
        val rlp = FrameLayout.LayoutParams(dp(84), dp(84))
        rlp.leftMargin = dp(56)
        art.addView(right, rlp)
        box.addView(art, LinearLayout.LayoutParams(dp(140), dp(84)))
        val a1 = ObjectAnimator.ofFloat(left, "translationX", 0f, dp(12).toFloat())
        val a2 = ObjectAnimator.ofFloat(right, "translationX", 0f, -dp(12).toFloat())
        for (a in listOf(a1, a2)) {
            a.duration = 1500
            a.repeatMode = ValueAnimator.REVERSE
            a.repeatCount = ValueAnimator.INFINITE
            a.start()
        }
        box.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) { a1.cancel(); a2.cancel() }
        })
        val t = tv("Nothing cloned yet", 20f, T.text, true)
        t.setPadding(0, dp(24), 0, dp(4))
        box.addView(t)
        box.addView(tv("Run a second copy of any app, with its own login.", 14f, T.muted))
        val btn = tv("Clone an app", 16f, Color.WHITE, true)
        btn.setPadding(dp(28), dp(14), dp(28), dp(14))
        btn.background = rr(T.accent, 28)
        btn.setOnClickListener { Haptic.tap(it, true); openPicker() }
        val blp = LinearLayout.LayoutParams(-2, -2)
        blp.topMargin = dp(22)
        box.addView(btn, blp)
        return box
    }


    // ---------------------------------------------------------------- engine actions
    private fun refresh() {
        Thread {
            var ids: List<Int> = listOf(0)
            val list = ArrayList<CloneItem>()
            try {
                val c = BlackBoxCore.get()
                val u = c.users.map { it.id }
                if (u.isNotEmpty()) ids = u
                val pm = BlackBoxCore.getPackageManager()
                val apps = c.getInstalledApplications(0, space)
                if (apps != null) {
                    for (ai in apps) {
                        try {
                            if (ai.packageName.isNullOrBlank()) continue
                            val icon: Drawable? = try { pm.getApplicationIcon(ai) } catch (e: Exception) { null }
                            list.add(CloneItem(ai.packageName, pm.getApplicationLabel(ai).toString(), icon))
                        } catch (e: Exception) {
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.w("Twin", "refresh: ${e.message}")
            }
            list.sortBy { it.label.lowercase() }
            runOnUiThread {
                spaceIds = ids
                if (!ids.contains(space) && !pendingNew) space = ids.first()
                clones = list
                if (tab == 0 || tab == 2) show(tab)
            }
        }.start()
    }

    private fun launch(item: CloneItem, v: View) {
        Haptic.tap(v)
        val sp = space
        Thread {
            val ok = try { BlackBoxCore.get().launchApk(item.pkg, sp) } catch (e: Throwable) { false }
            runOnUiThread {
                if (ok) {
                    Store.launches = Store.launches + 1
                    Store.addMessage("Opened ${item.label}", "Launched in ${Store.spaceName(sp)}.")
                } else {
                    Store.addMessage("Couldn't open ${item.label}", "The app didn't start. Try Clear data, or clone it again.")
                    toast("Couldn't open ${item.label}")
                }
            }
        }.start()
    }

    private fun holdMenu(item: CloneItem, v: View) {
        Haptic.tap(v, true)
        AlertDialog.Builder(this)
            .setTitle(item.label)
            .setItems(arrayOf("Open", "Clear data", "Remove clone")) { _, which ->
                when (which) {
                    0 -> launch(item, v)
                    1 -> confirm("Clear ${item.label}'s data?", "Logins and files inside this clone will be erased.") { clearData(item) }
                    else -> if (Store.confirmRemove) {
                        confirm("Remove ${item.label}?", "The clone and its data are deleted. Your original app is untouched.") { removeClone(item) }
                    } else removeClone(item)
                }
            }
            .show()
    }

    private fun confirm(title: String, body: String, go: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(body)
            .setPositiveButton("Yes") { _, _ -> go() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearData(item: CloneItem) {
        val sp = space
        Thread {
            try { BlackBoxCore.get().clearPackage(item.pkg, sp) } catch (e: Throwable) { Log.w("Twin", "clear: ${e.message}") }
            runOnUiThread {
                Store.addMessage("Cleared ${item.label}", "Data erased in ${Store.spaceName(sp)}.")
                toast("Data cleared")
            }
        }.start()
    }

    private fun removeClone(item: CloneItem) {
        val sp = space
        Thread {
            try {
                BlackBoxCore.get().uninstallPackageAsUser(item.pkg, sp)
                prune()
            } catch (e: Throwable) {
                Log.w("Twin", "remove: ${e.message}")
            }
            runOnUiThread {
                Store.addMessage("Removed ${item.label}", "Deleted from ${Store.spaceName(sp)}.")
                refresh()
            }
        }.start()
    }

    // Same clean-up the engine's own app does: drop trailing empty spaces.
    private fun prune() {
        try {
            val c = BlackBoxCore.get()
            val list = c.users
            if (list.isEmpty()) return
            val id = list.last().id
            if (c.getInstalledApplications(0, id).isEmpty()) {
                c.deleteUser(id)
                prune()
            }
        } catch (e: Throwable) {
        }
    }

    private fun newSpace() {
        val next = (spaceIds.maxOrNull() ?: -1) + 1
        pendingNew = true
        space = next
        clones = emptyList()
        show(0)
        toast("New space ready. Tap + to add an app.")
    }

    private fun renameSpace(id: Int) {
        val input = EditText(this)
        input.setText(Store.spaceName(id))
        input.setSelectAllOnFocus(true)
        AlertDialog.Builder(this)
            .setTitle("Rename space")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) Store.setSpaceName(id, n)
                show(0)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openPicker() {
        val i = Intent(this, PickerActivity::class.java)
        i.putExtra("userID", space)
        startActivityForResult(i, 31)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 31 && resultCode == RESULT_OK && data != null) {
            val source = data.getStringExtra("source") ?: return
            install(source, data.getStringExtra("name") ?: "app")
        }
    }

    private fun install(source: String, name: String) {
        val sp = space
        val dlg = AlertDialog.Builder(this).setMessage("Cloning $name\u2026").setCancelable(false).create()
        dlg.show()
        Thread {
            var ok = false
            var msg = ""
            try {
                val r = BlackBoxCore.get().installPackageAsUser(source, sp)
                ok = r.success
                msg = r.msg ?: ""
            } catch (e: Throwable) {
                msg = e.message ?: "unknown error"
            }
            runOnUiThread {
                dlg.dismiss()
                if (ok) {
                    pendingNew = false
                    Store.addMessage("Cloned $name", "Added to ${Store.spaceName(sp)}.")
                    Haptic.tap(content, true)
                    toast("$name cloned")
                } else {
                    Store.addMessage("Couldn't clone $name", if (msg.isEmpty()) "Cloning failed." else msg)
                    toast("Couldn't clone $name")
                }
                refresh()
            }
        }.start()
    }

    // ---------------------------------------------------------------- messages page
    private fun storageOk(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    private fun gb(b: Long): String = String.format(Locale.US, "%.1f GB", b / 1073741824.0)

    private fun messagesPage(): View {
        val col = page("Messages", "Device status and clone activity")

        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
        val stat = StatFs(Environment.getDataDirectory().path)
        val free = stat.availableBytes
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)

        val alerts = ArrayList<Pair<String, String>>()
        if (pct in 0..19 && !charging) alerts.add("Battery is low" to "Only $pct% left. Cloned apps keep running in the background.")
        if (free < 2L * 1073741824L) alerts.add("Storage is almost full" to "${gb(free)} free. Clones need space to run.")
        if (!storageOk()) alerts.add("Storage access needed" to "Open Settings to allow it so clones can save files.")
        for (a in alerts) {
            val c = card()
            c.background = rr(if (T.dark) Color.parseColor("#3A2420") else Color.parseColor("#FFE8E1"), 20)
            c.addView(tv(a.first, 16f, T.text, true))
            c.addView(tv(a.second, 13f, T.muted))
            addTo(col, c)
        }

        val status = card()
        status.addView(tv("This device", 16f, T.text, true))
        val facts = listOf(
            "Battery" to (if (pct >= 0) "$pct%" + (if (charging) " \u00B7 charging" else "") else "unknown"),
            "Storage" to "${gb(free)} free of ${gb(stat.totalBytes)}",
            "Memory" to "${gb(mi.availMem)} free of ${gb(mi.totalMem)}",
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        )
        for (f in facts) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.setPadding(0, dp(8), 0, 0)
            r.addView(tv(f.first, 14f, T.muted), LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(tv(f.second, 14f, T.text, true))
            status.addView(r)
        }
        addTo(col, status)

        section(col, "Activity")
        val msgs = Store.messages()
        if (msgs.isEmpty()) {
            val e = card()
            e.addView(tv("No activity yet", 16f, T.text, true))
            e.addView(tv("Opening, cloning and removing apps will show up here.", 13f, T.muted))
            addTo(col, e)
        } else {
            val now = System.currentTimeMillis()
            for (m in msgs) {
                val c = card()
                val top = LinearLayout(this)
                top.orientation = LinearLayout.HORIZONTAL
                top.addView(tv(m.title, 15f, T.text, true), LinearLayout.LayoutParams(0, -2, 1f))
                top.addView(tv(DateUtils.getRelativeTimeSpanString(m.time, now, DateUtils.MINUTE_IN_MILLIS).toString(), 12f, T.muted))
                c.addView(top)
                c.addView(tv(m.body, 13f, T.muted))
                addTo(col, c)
            }
        }
        return scroll(col)
    }

    // ---------------------------------------------------------------- profile page
    private fun profilePage(): View {
        val col = page("Profile", null)
        val avatar = tv(Store.name.take(1).uppercase(Locale.getDefault()), 40f, Color.WHITE, true)
        avatar.gravity = Gravity.CENTER
        val ag = GradientDrawable()
        ag.shape = GradientDrawable.OVAL
        ag.setColor(T.coral)
        avatar.background = ag
        val alp = LinearLayout.LayoutParams(dp(96), dp(96))
        alp.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(avatar, alp)

        val name = tv(Store.name, 24f, T.text, true)
        name.gravity = Gravity.CENTER
        name.setPadding(0, dp(14), 0, 0)
        name.setOnClickListener { Haptic.tap(it); editName() }
        col.addView(name, LinearLayout.LayoutParams(-1, -2))
        val hint = tv("Tap your name to edit", 12f, T.muted)
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(2), 0, dp(18))
        col.addView(hint, LinearLayout.LayoutParams(-1, -2))

        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        val data = listOf(
            clones.size.toString() to "Clones here",
            spaceIds.size.toString() to "Spaces",
            Store.launches.toString() to "Launches"
        )
        for ((i, d) in data.withIndex()) {
            val c = card()
            c.gravity = Gravity.CENTER_HORIZONTAL
            c.addView(tv(d.first, 26f, T.accent, true))
            c.addView(tv(d.second, 12f, T.muted))
            val lp = LinearLayout.LayoutParams(0, -2, 1f)
            if (i < data.size - 1) lp.rightMargin = dp(10)
            stats.addView(c, lp)
        }
        addTo(col, stats)

        val info = card()
        val fmt = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        info.addView(rowInfo("Device", "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"))
        divider(info)
        info.addView(rowInfo("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"))
        divider(info)
        info.addView(rowInfo("Using Twin since", fmt.format(Date(Store.since))))
        addTo(col, info)
        return scroll(col)
    }

    private fun rowInfo(k: String, v: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(0, dp(12), 0, dp(12))
        r.addView(tv(k, 14f, T.muted), LinearLayout.LayoutParams(0, -2, 1f))
        val valueView = tv(v, 14f, T.text, true)
        valueView.gravity = Gravity.END
        r.addView(valueView, LinearLayout.LayoutParams(0, -2, 1.4f))
        return r
    }

    private fun editName() {
        val input = EditText(this)
        input.setText(Store.name)
        input.setSelectAllOnFocus(true)
        AlertDialog.Builder(this)
            .setTitle("Your name")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) Store.name = n
                show(2)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------------------------------------------------------- settings page
    private fun settingsPage(): View {
        val col = page("Settings", null)

        section(col, "Feel")
        val c1 = card()
        c1.addView(rowSwitch("Haptic feedback", "A small tap on buttons and actions", Store.haptics) { Store.haptics = it })
        addTo(col, c1)

        section(col, "Look")
        val c2 = card()
        val themeNames = arrayOf("Match system", "Light", "Dark")
        c2.addView(rowTap("Theme", themeNames[Store.theme.coerceIn(0, 2)]) {
            AlertDialog.Builder(this)
                .setTitle("Theme")
                .setSingleChoiceItems(themeNames, Store.theme) { d, w ->
                    Store.theme = w
                    d.dismiss()
                    recreate()
                }
                .show()
        })
        addTo(col, c2)

        section(col, "Safety")
        val c3 = card()
        c3.addView(rowSwitch("Confirm before removing", "Ask first when deleting a clone", Store.confirmRemove) { Store.confirmRemove = it })
        divider(c3)
        c3.addView(rowTap("Storage access", if (storageOk()) "Allowed" else "Needed. Tap to open settings") { askStorage() })
        addTo(col, c3)

        section(col, "Data")
        val c4 = card()
        c4.addView(rowTap("Clear messages", "Remove the activity list") {
            Store.clearMessages()
            toast("Messages cleared")
        })
        divider(c4)
        c4.addView(rowTap("Reset profile", "Clear your name, launch count and messages") {
            confirm("Reset profile?", "Your cloned apps are not affected.") {
                Store.resetProfile()
                toast("Profile reset")
                show(3)
            }
        })
        addTo(col, c4)

        section(col, "About")
        val c5 = card()
        c5.addView(tv("Twin 1.0", 16f, T.text, true))
        c5.addView(tv("No ads. No trackers. Everything stays on your device.", 13f, T.muted))
        val p = tv("Powered by the open-source BlackBox virtualization engine (Apache-2.0).", 12f, T.muted)
        p.setPadding(0, dp(10), 0, 0)
        c5.addView(p)
        addTo(col, c5)
        return scroll(col)
    }

    // ---------------------------------------------------------------- permissions
    private fun ensureStorage() {
        if (storageOk() || Store.askedStorage) return
        Store.askedStorage = true
        AlertDialog.Builder(this)
            .setTitle("Allow storage access")
            .setMessage("Twin needs \u201CAll files access\u201D so cloned apps can save their files. You can change this later in Settings.")
            .setPositiveButton("Open settings") { _, _ -> askStorage() }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun askStorage() {
        if (Build.VERSION.SDK_INT < 30) { toast("Nothing to allow on this Android version"); return }
        try {
            val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (e2: Exception) {}
        }
    }
}

class CloneAdapter(
    private val ctx: Context,
    private val items: List<CloneItem>,
    private val onTap: (CloneItem, View) -> Unit,
    private val onHold: (CloneItem, View) -> Unit
) : RecyclerView.Adapter<CloneAdapter.VH>() {

    class VH(val root: LinearLayout, val icon: ImageView, val name: TextView) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(ctx.dp(4), ctx.dp(10), ctx.dp(4), ctx.dp(10))
        val icon = ImageView(ctx)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(icon, LinearLayout.LayoutParams(ctx.dp(60), ctx.dp(60)))
        val name = ctx.tv("", 12f, T.text)
        name.gravity = Gravity.CENTER
        name.maxLines = 2
        name.ellipsize = TextUtils.TruncateAt.END
        val nlp = LinearLayout.LayoutParams(-1, -2)
        nlp.topMargin = ctx.dp(6)
        root.addView(name, nlp)
        root.layoutParams = RecyclerView.LayoutParams(-1, -2)
        return VH(root, icon, name)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.icon.setImageDrawable(item.icon)
        h.name.text = item.label
        h.root.setOnClickListener { v -> onTap(item, v) }
        h.root.setOnLongClickListener { v -> onHold(item, v); true }
    }

    override fun getItemCount(): Int = items.size
}
