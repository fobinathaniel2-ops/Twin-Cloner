package top.niunaijun.blackboxa.view.main

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import top.niunaijun.blackboxa.view.twin.Haptic
import top.niunaijun.blackboxa.view.twin.Store
import top.niunaijun.blackboxa.view.twin.TwinHomeActivity

/** Twin animated splash: two circles slide together, a ring pulses out, the name fades in. */
class SplashActivity : Activity() {
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        val teal = Color.parseColor("#0F3D3E")
        val coral = Color.parseColor("#FF6B4A")
        val bone = Color.parseColor("#F3EFE7")
        window.statusBarColor = teal
        window.navigationBarColor = teal
        val d = resources.displayMetrics.density

        fun disc(color: Int, size: Int) = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
            }
            layoutParams = FrameLayout.LayoutParams((size * d).toInt(), (size * d).toInt(), Gravity.CENTER)
        }

        val glow = disc(Color.argb(90, 255, 107, 74), 96).apply { alpha = 0f; scaleX = 0.8f; scaleY = 0.8f }
        val left = disc(bone, 96).apply { alpha = 0f; scaleX = 0.6f; scaleY = 0.6f; translationX = -230 * d }
        val right = disc(coral, 96).apply { alpha = 0f; scaleX = 0.6f; scaleY = 0.6f; translationX = 230 * d }

        val title = TextView(this).apply {
            text = "Twin"
            textSize = 38f
            setTextColor(bone)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            letterSpacing = -0.03f
            alpha = 0f
        }
        val tagline = TextView(this).apply {
            text = "Two of everything. Zero ads."
            textSize = 14f
            setTextColor(bone)
            alpha = 0f
        }
        val labels = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(title)
            addView(tagline)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ).apply { topMargin = (150 * d).toInt() }
            translationY = 24 * d
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(teal)
            addView(glow)
            addView(left)
            addView(right)
            addView(labels)
            setOnClickListener { proceed() }
        }
        setContentView(root)

        left.animate().alpha(1f).scaleX(1f).scaleY(1f).translationX(-30 * d)
            .setDuration(800).setInterpolator(OvershootInterpolator(0.8f)).start()
        right.animate().alpha(1f).scaleX(1f).scaleY(1f).translationX(30 * d)
            .setDuration(800).setInterpolator(OvershootInterpolator(0.8f))
            .withEndAction { Haptic.tap(root, true) }.start()

        // ring pulse as the circles meet
        glow.animate().alpha(1f).setStartDelay(650).setDuration(120).withEndAction {
            glow.animate().scaleX(4.5f).scaleY(4.5f).alpha(0f).setStartDelay(0).setDuration(700)
                .setInterpolator(DecelerateInterpolator()).start()
        }.start()

        title.animate().alpha(1f).setStartDelay(600).setDuration(500).start()
        labels.animate().translationY(0f).setStartDelay(600).setDuration(600)
            .setInterpolator(DecelerateInterpolator()).start()
        tagline.animate().alpha(0.75f).setStartDelay(950).setDuration(500)
            .withEndAction { root.postDelayed({ proceed() }, 650) }.start()
    }

    private fun proceed() {
        if (done) return
        done = true
        startActivity(Intent(this, TwinHomeActivity::class.java))
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
